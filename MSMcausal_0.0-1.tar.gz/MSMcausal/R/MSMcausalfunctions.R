### Auxiliary functions ############################

##' @title An auxiliary function which fits a classfication tree using the rpart function from the rpart package
##' @param Formula a formula, with a response but no interaction terms
##' @param D a data frame in which to interpret the variables named in the formula
##' @return Tree an object with class rpart representing the fitted classification tree
##' @author Ce Yang, Yuan Tian, Wenling Zhang
CTree <- function(Formula, D){
  Treetry <- rpart::rpart(Formula, data=D, method = "class", parms = list(split = "gini"), cp = 0)
  means <- Treetry$cptable[,4]
  nnum <- which.min(means)
  CP <- mean(Treetry$cp[c(nnum-1,nnum)])
  if(CP<0) CP=0
  Tree <- rpart::rpart(Formula, data=D, method = "class", parms = list(split = "gini"), cp = CP)
  Tree
}


##' @title An auxiliary function which trains a random forest using the function from the randomForest package
##' @param Form a formula which includes a response and some predictor variables but no interaction terms
##' @param D a data frame in which to interpret the variables named in the formula
##' @return rf a list of objects representing the fitted random forest
##' @author Ce Yang, Yuan Tian, Wenling Zhang
Rf <- function(Form, D){
    rf <- randomForest::randomForest(Form, data = D,
    ntree = 501,
    replace = TRUE,
    nodesize = 3,
    importance = FALSE)
    rf
}

##' @title An auxiliary function which trains Bootstrap aggregated classification and regression trees using the function from the ipred package
##' @param Form a formula which include a response and some predictor variables but no interaction terms
##' @param D a data frame in which to interpret the variables named in the formula
##' @return bag a list of objects representing the fitted model
##' @author Ce Yang, Yuan Tian, Wenling Zhang
Bag <- function(Form, D){
    bag <- ipred::bagging(Form, data = D, coob = TRUE)
    bag
}

##' @title An auxiliary function which applies GLM with binomial distribution
##' @param Form a formula which include a response and some predictor variables
##' @param D a data frame in which to interpret the variables named in the formula
##' @return binglm contains the binomial GLM output
##' @author Ce Yang, Yuan Tian, Wenling Zhang
BinGLM <- function(Form, D){
    binglm <- glm(Form, data = D, family = "binomial", na.action = na.fail)
    binglm
}


##' @title An auxiliary function which computes weights as a cumulative product
##' @param DD a data frame in which to interpret the variables named in the formula
##' @param nu a vector containing numbers for the numerator of the weight
##' @param de a vector containing numbers for the denominator of the weight
##' @param column a positive integer indicating which column of the data set records the subject number
##' @param i a positive integer indicating the function is calculating the weight for which subject
##' @return weighti an object with class vector
##' @author Ce Yang, Yuan Tian, Wenling Zhang
weightcal <- function(DD, nu, de, column, i){
  indexi <- which(DD[ ,column] == i)            # For each patient i, how many time points are there
  weighti <- pmin(10, cumprod(nu[indexi])/cumprod(de[indexi]))
  weighti
}




### Exported functions ############################

##' @title Exported function which computes weights of the dataset
##' @param D a data frame in which to interpret the variables named in the formula
##' @param pacol a positive integer indicating which column of the data set records the subject number
##' @param treatcol a positive integer indicating which column of the data set records the treatment factor
##' @param numformula a formula, with a response but no interaction terms
##' @param denomformula a formula, with a response but no interaction terms
##' @param stabilized logical value: if TRUE, the function calculates the stabilized weight
##' @param method character string indicating the approach to be used for estimating the denominator and numerator
##' @return weight an object with class vector representing the weight of the whole dataset
##' @author Ce Yang, Yuan Tian, Wenling Zhang
MSMweight <- function(D, pacol, treatcol, numformula, denomformula, stablized = TRUE, method = c("tree", "rf","bagging")){
    
    #if(!require(rpart,quietly = TRUE))
    #stop("Package 'rpart' must be installed")
    #if(!require(randomForest,quietly = TRUE))
    #stop("Package 'rpart' must be installed")
    #if(!require(ipred,quietly = TRUE))
    #stop("Package 'rpart' must be installed")

  stopifnot(is.data.frame(D),
            ncol(D) > 1, nrow(D) > 1,     # sanity checks
            all(lapply(apply(D,2,unique), length) > 1),
                                          # check for each column having unidentical inputs so that the variable is informative for our model
            pacol %%1 == 0, pacol > 0,
            treatcol %%1 == 0, treatcol > 0 )

            
  method <- match.arg(method)
  switch(method,
         
  "tree" = {
      num <- predict(CTree(numformula, D))     # output of the classfication tree for the numerator
      den <- predict(CTree(denomformula, D))   # output of the classfication tree for the denominator
  },
  
  "rf" = {
      num <- predict(Rf(numformula, D))     # output of the random forest for the numerator
      den <- predict(Rf(denomformula, D))   # output of the random forest tree for the denominator
      num <- cbind(1-num, num)
      den <- cbind(1-den, den)
  },
  
  "bagging" = {
      num <- predict(Bag(numformula, D))     # output of the bagging for the numerator
      den <- predict(Bag(denomformula, D))   # output of the bagging for the denominator
      num <- cbind(1-num, num)
      den <- cbind(1-den, den)
  },
  
  stop("Wrong 'method'"))
  
  numer <- rep(1,nrow(D))                  # numerator for each row of the dataset, default 1 i.e. unstabilized weight
  denom <- numeric(nrow(D))                # denominator for each row of the dataset
  
  for (i in 1:nrow(D)) {
    denom[i] <- pmax(0.01, den[i, ifelse(D[, treatcol][i] == 1, 2, 1)])  # to make sure denominator is not zero.
  }
  
  if (stablized == TRUE) {
    for (i in 1:nrow(D)) {
      numer[i] <- pmax(0.01, num[i, ifelse(D[, treatcol][i] == 1, 2, 1)]) # replace unstabilized weight by stabilized ones
    } 
  }
  
  weightt <- unlist(lapply(c(min(unique(D[, pacol])):max(unique(D[, pacol]))), weightcal, DD = D, nu = numer, de = denom, column = pacol))
  # the weight is a cumulative product calculated by calling the auxiliary function 'weightcal'
  weight <- ifelse(is.finite(weightt), weightt, 1)

  weight
}



##' @title Exported function which fits a marginal structual model given the weights
##' @param D a data frame in which to interpret the variables named in the formula
##' @param W a vector of case weights 
##' @param rescol a positive integer indicating which column of the data set records the subject number
##' @param treatcol a positive integer indicating which column of the data set records the treatment factor
##' @param t1col a positive integer indicating which column of the data set records the starting time of the observation
##' @param t2col a positive integer indicating which column of the data set records the end time of the observation
##' @param method character string indicating the approach to be used to fit the marginal structual model
##' @param round logical value: if TRUE, the function expands the dataset by rounding the weights
##' @return Result an object with class summary.glm or summary.coxph or summary.aareg representing the summary of the model
##' @author Ce Yang, Yuan Tian, Wenling Zhang
MSMmodel <- function(D, W, rescol, treatcol, t1col, t2col, method = c("glm", "Cox", "Additive"), round = TRUE){
  
  stopifnot(ncol(D) > 1,
            nrow(D) > 1,                
            is.data.frame(D),
            length(W) == nrow(D), 
            all(lapply(apply(D,2,unique), length) > 1),
            rescol %%1 ==0, rescol > 0,
            treatcol %%1 ==0, treatcol > 0,
            t1col %%1 ==0, t1col > 0,
            t2col %%1 ==0, t2col > 0)
  
  if (round == TRUE) {                          
    N <- round(10*W) + 1                          # rounded up to the first decimal place; each row at least has single contribution.
    ND <- data.frame(D, N)
    ED <- ND[rep(row.names(ND), ND$N), 1:ncol(D)] # Expanded data set using the weights in the inputs.
    Wn <- rep(1, nrow(ED))
  }else{
    ED <- D
    Wn <- W
  }
  method <- match.arg(method)
  switch(method,
         "glm" = {
           Result <- summary(glm(ED[, rescol] ~ ED[, treatcol], family = binomial, weights = Wn , data = ED))
         },
         
         "Cox" = {
           Result <- summary(coxph(Surv(ED[, t1col], ED[, t2col], ED[, rescol]) ~ ED[, treatcol], weights = Wn, data = ED))
         },
         
         "Additive" = {
             Result <- summary(aareg(Surv(ED[, t1col], ED[, t2col], ED[, rescol]) ~ ED[, treatcol], weights = Wn, data = ED))
         },
         
         stop("Wrong 'method'"))
  
  Result
}




## Exported functions ############################

##' @title Exported function which computes weights of the dataset
##' @param D a data frame in which to interpret the variables named in the formula
##' @param pacol -> id a character indicating which column of the data set records the subject number
##' @param treatcol -> exposure a character indicating which column of the data set records the treatment factor
##' @param numformula a formula, with a response but no interaction terms
##' @param denomformula a formula, with a response but no interaction terms
##' @param stabilized logical value: if TRUE, the function calculates the stabilized weight
##' @param method character string indicating the approach to be used for estimating the denominator and numerator
##' @return weight an object with class vector representing the weight of the whole dataset
##' @author Ce Yang, Wenling Zhang, Yuan Tian
MSMweight_alt <- function(D, pacol, timevar, treatcol, numformula, denomformula, stablized = TRUE, method = c("tree", "rf", "bagging","glm"))
{
    ### check inputs
    local.call <- match.call()
    
    
    stopifnot(is.data.frame(D),
    ncol(D) > 1, nrow(D) > 1,     # sanity checks
    all(lapply(apply(D,2,unique), length) > 1)
    # check for each column having unidentical inputs so that the variable is informative for our model
    )
    
    
    ### construct a local dataset
    local.data       <- data.frame(exposure = D[,as.character(local.call$treatcol)])  # defining exposure
    local.data$p.num <- rep(0,nrow(D))                                                # defining probabilty for each id@num
    local.data$p.den <- rep(0,nrow(D))                                                # defining probabilty for each id@den
    local.data$w.num <- rep(0,nrow(D))                                                # defining weight for each id@num
    local.data$w.den <- rep(0,nrow(D))                                                # defining weight for each id@den
    if (("pacol" %in% names(local.call)))
    {
        local.data$id                              <- eval(parse(text = paste("D$",deparse(local.call$pacol),sep = "")))
        local.data$time                            <- eval(parse(text = paste("D$",deparse(local.call$timevar),sep = "")))
        
        local.data <- local.data[order(local.data$id,local.data$time), ]
        
        local.data$tvc  <- do.call("c", lapply(split(local.data$exposure, local.data$id),
        function (x) if(!is.na(match(1,x)))
        return(c(rep(1,match(1,x)), rep(0,length(x) - match(1,x))))
        else return(rep(1,length(x)))))
    }
    
    
    ### assign model outputs
    method <- match.arg(method)
    switch(method,
    
    "tree" = {
        num <- predict(CTree(numformula, D))     # output of the classfication tree for the numerator
        den <- predict(CTree(denomformula, D))   # output of the classfication tree for the denominator
    },
    
    "rf" = {
        num <- predict(Rf(numformula, D))     # output of the random forest for the numerator
        den <- predict(Rf(denomformula, D))   # output of the random forest tree for the denominator
    },
    
    "bagging" = {
        num <- predict(Bag(numformula, D))     # output of the bagging for the numerator
        den <- predict(Bag(denomformula, D))   # output of the bagging for the denominator
    },
    
    "glm" = {
        num <- 1 / (1 + exp(-predict(BinGLM(numformula, D))))     # output of the binomial GLM for the numerator
        den <- 1 / (1 + exp(-predict(BinGLM(denomformula, D))))   # output of the binomial GLM for the denominator
    },
    
    stop("Wrong 'method'"))
    
    
    ### determine the weights
    if(!("pacol" %in% names(local.call))){
        if(!(("tree") %in% method)){
            local.data$w.num[local.data$exposure == 0] <- 1 - num[local.data$exposure == 0]
            local.data$w.num[local.data$exposure == 1] <-     num[local.data$exposure == 1]
            local.data$w.den[local.data$exposure == 0] <- 1 - den[local.data$exposure == 0]
            local.data$w.den[local.data$exposure == 1] <-     den[local.data$exposure == 1]
        }else{
            local.data$w.num <- num[,2]
            local.data$w.den <- num[,2]
        }
        
    }else{
        if(!(("tree") %in% method)){
            local.data$p.num[local.data$exposure == 0] <- 1 - num[local.data$exposure == 0]
            local.data$p.num[local.data$exposure == 1] <-     num[local.data$exposure == 1]
            local.data$p.den[local.data$exposure == 0] <- 1 - den[local.data$exposure == 0]
            local.data$p.den[local.data$exposure == 1] <-     den[local.data$exposure == 1]
        }else{
            local.data$p.num <- num[,2]
            local.data$p.den <- num[,2]
        }
        
        local.data$p.num[local.data$tvc == 0] <- 1
        local.data$p.den[local.data$tvc == 0] <- 1
        
        local.data$w.num <- unlist(lapply(split(local.data$p.num,local.data$id),function(x) cumprod(x)))
        local.data$w.den <- unlist(lapply(split(local.data$p.den,local.data$id),function(x) cumprod(x)))
    }
    
    if(!stablized)
    {
        local.data$w.num <- 1
    }
    
    local.data$w.ipw <- local.data$w.num / local.data$w.den
    
    return(list(weights.alt = local.data$w.ipw, out.data.alt = local.data))
}


##' @title Exported function which outputs the plots for visualizing the weights
##' @param D a data frame in which to interpret the variables named in the formula
##' @param rescol -> id a character indicating which column of the data set records the subject number
##' @param selected a numeric vector which indicates the id of the selected observation(s)
##' @param w a vector of case weights
##' @param timevar name of time variable which indicates the end time of the observation
##' @param binwidth specific bin width for the box plot - applied only in the time dependent case
##' @param logscale logical value, if the user wants to logscale the xaxis
##' @param ref_line logical value, if the user wants a reference line to be added default TRUE
##' @param xlim a numeric vector indicates the range of x-axis
##' @param ylim a numeric vector indicates the range of y-axis
##' @param xlab label of x-axis
##' @param ylab label of y-axis
##' @return plot of weights
##' @author Ce Yang, Yuan Tian, Wenling Zhang

MSMplot <- function(D, rescol, selected, w, timevar, binwidth, logscale = TRUE, ref_line = TRUE, xlim = c(0,5),
ylim = c(0,8), xlab = "x", ylab = "y", ...){
    local.call <- match.call()
    if(!("D" %in% names(local.call)))
    stop("No data sepcified")
    local.data <- data.frame(weights = D[,as.character(local.call$w)])
    if("timevar" %in% names(local.call)){
        local.data$timevar <- eval(parse(text = paste("D$",deparse(local.call$timevar),sep = "")))
        if(("rescol" %in% names(local.call)))
        {
            if("binwidth" %in% names(local.call)){
                local.data$timevar <- round(local.data$timevar / binwidth) * binwidth
            }
            local.data$id <- eval(parse(text = paste("D$",deparse(local.call$rescol),sep = "")))
            local.x <- selected
            cols <- 1:length(local.x)
            if(logscale){
                opar <- par(pty = "m")
                plot(NA, xlim = xlim, ylim = ylim, xlab = xlab, ylab = ylab,... )
                for(i in local.x) lines(density(log(local.data$weights[local.data$id == i])), col = cols[i])
                legend("topright", lty = rep(1,length(local.x)), col = cols,
                legend = as.expression(lapply(local.x, function(j) substitute(rescol == j., list(j. = j)))))
                if(ref_line)
                abline(v = 1, lty = 2, lwd = 2)
                par(opar)
                
            }else{
                opar <- par(pty = "m")
                plot(NA, xlim = xlim, ylim = ylim, xlab = xlab, ylab = ylab,... )
                for(i in local.x) lines(density(local.data$weights[local.data$id == i]), col = cols[i])
                legend("topright", lty = rep(1,length(local.x)), col = cols,
                legend = as.expression(lapply(local.x, function(j) substitute(rescol == j., list(j. = j)))))
                if(ref_line)
                abline(v = 1, lty = 2, lwd = 2)
                par(opar)      }
        }else{
            if(logscale){
                boxplot(log(local.data$weights) ~ local.data$timevar, pch = 20, xlab = xlab, ylab = ylab, ...)
                if(ref_line)
                abline(h = 0, lty = 2)
            }else{
                boxplot(local.data$weights ~ local.data$timevar, pch = 20, xlab = xlab, ylab = ylab, ...)
                if(ref_line)
                abline(h = 1, lty = 2)
            }
        }
    }else{
        if(logscale){
            plot(density(log(local.data$weights)), pch = 20, xlim = xlim, ylim = ylim, xlab = xlab, ylab = ylab, ...)
            if(ref_line)
            abline(v = 0, lty = 2)
        }else{
            plot(density(local.data$weights), pch = 20, xlim = xlim, ylim = ylim, xlab = xlab, ylab = ylab, ...)
            if(ref_line)
            abline(v = 1, lty = 2)
        }
    }
}




